from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.

#custom model
class User(AbstractUser) :
    class Role(models.TextChoices):
        ADMIN="ADMIN", 'Admin'
        CUSTOMER="CUSTOMER",'Customer'
        MANAGER="MANAGER", 'Manager'
    Base_role= Role.MANAGER
    role=models.CharField(max_length=50,choices=Role.choices)    

    def save(self,*args,**kwargs) :
        if not self.pk :
            self.role=self.Base_role
            return super().save(*args,**kwargs)
        else :
            print("Not a new user")
        

class product1(models.Model):
    username = models.CharField(max_length=122)
    taste = models.IntegerField()
    freshness = models.IntegerField()
    h_cnt = models.IntegerField()
    flv = models.IntegerField()
    delivery = models.IntegerField()
    pname = models.CharField(max_length=122,default="orange")
    
    def __str__(self):
        return self.username

class sales(models.Model):
    pname2 = models.CharField(max_length=122,default="orange")
    month = models.CharField(max_length=122)
    year = models.IntegerField()
    total_sal=models.IntegerField()
    total_pro = models.IntegerField()
    cst = models.IntegerField()
    sel = models.IntegerField()
    





